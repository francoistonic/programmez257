$userData = array();
foreach ($userList as $user) {
    $userData[] = '("'. $user['ﬁrst_name'] .'", "'.
    $user['last_name'] .'")';
}
$query = 'INSERT INTO users (ﬁrst_name,last_name) VALUES'. implode(',', $userData); mysql_query($query);
